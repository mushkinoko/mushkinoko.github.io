#!/bin/bash
cd `dirname $0`
echo "----- WinXPTheme(ja) Installer -----"
echo ""
echo "----- (c) 2017 takusan. -----"
echo ""
echo "Do you want to install? [Y/n]"
read answer
echo ""
case $answer in
  "" | "Y" | "y" | "Yes" | "yes" | "YES" )
    echo "Copying files..."
    echo ""
    mkdir $HOME/.themes
    mkdir $HOME/.icons
    cp -R themes $HOME/.themes/WinXPTheme
    cp -R icons $HOME/.icons/WinXPTheme
    echo ""
    echo "Installation finished." ;;
  * ) echo "Insallation aborted." ;;
esac
